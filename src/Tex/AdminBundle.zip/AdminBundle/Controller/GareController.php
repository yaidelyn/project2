<?php


namespace Tex\AdminBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Utils\UserComponent;
use Tex\AdminBundle\Entity\Gare;
use Symfony\Component\HttpFoundation\Response;
use Tex\AdminBundle\Entity\GareTeam;
use Tex\AdminBundle\Entity\ResultGara;
use Tex\AdminBundle\Entity\UserSelectGara;
use Tex\UsuarioBundle\Entity\Team;
use Symfony\Component\Serializer\Encoder\JsonEncoder;

class GareController  extends Controller
{

    var $user_comp;

    public function __construct(){
        $this->user_comp = new UserComponent($this);
    }

    public function indexAction(){

    }

    public function createGareAction(){
        $em = $this->get('doctrine')->getManager();
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();
        if(!empty($_POST)){
        // echo '<pre>';print_r($_POST);die;
            $gare = new Gare();

            $scadenza_gara = $_POST['data']['scadenza_gare'];
            $scadenza_candi = $_POST['data']['scadenza_candi'];

            $tipologia = $em->getRepository('AdminBundle:TipologiaGara')->find($_POST['data']['tipologia']);

           // $gare->setCategory($category);
            $gare->setTitle($_POST['data']['title']);
            $gare->setRifBando($_POST['data']['rifbando']);
            $gare->setScadenzaGara(new \DateTime($scadenza_gara));
            $gare->setScadenzaCanditura(new \DateTime($scadenza_candi));
            $gare->setCodGara($_POST['data']['cod_gara']);
            $gare->setImporte($_POST['data']['importe']);
            $gare->setTipologia($tipologia);
            $gare->setObjective($_POST['data']['objetive']);
            $gare->setCapTeam($_POST['data']['tipologia']);


            foreach($_POST['data']['idopere'] as $val){
                $opere = $em->getRepository('AdminBundle:Opere')->findOneBy(array(
                    'code'=>$val
                ));

                $gare->addOpere($opere);
            }


            $id_gare = $gare->getId();
            //add gare Team

            foreach($_POST['data']['name_rol'] as $rol){
                $gareteam = new GareTeam();
                //$gareteam->setGare($gare);
                $gareteam->setNameRol($rol['name']);
                $gareteam->setCantidad($rol['cantidad']);
                //$gareteam->addGare($gare);

                $em->persist($gareteam);
                $em->flush();

                $gare->addGareteam($gareteam);
            }

            $em->persist($gare);
            $em->flush();

            $response = array("code" => 1, "success" => true,'mensaje'=>'Ha inserito correttamente i dati della gara');
            return new Response(json_encode($response));

        }else{

            $result = $this->user_comp->getPersonalsInfo($id);
            $result['active_gare'] = 'active';
            $result['create_gare'] = 'active';
            $projects = $this->user_comp->getAllProjects();
            $categories = $this->getAllCategory();


            return $this->render('AdminBundle:Admin:create_gare.html.twig', array(
                'datos'=>$result,
                'projects'=>$projects,
                'categories'=>$categories,
                'operes'=>$this->getAllOpere(),
                'subcategoperes'=>$this->allSubcategoryOpere(),
                'tipologias'=>$this->getTipologiasGara()
            ));


        }
    }

    public function getAllCategory(){

        $em = $this->get('doctrine')->getManager();
        $categories = $em->getRepository('AdminBundle:CategOffer' )->findAll();

        foreach($categories as $item){

            $array['id'] = $item->getId();
            $array['name'] = $item->getName();

            $result[] = $array;
        }

        //echo '<pre>';print_r($result);die;
        return $result;

    }


    //get all oper
    public function getAllOpere(){
        $em = $this->get('doctrine')->getManager();
        $operes = $em->getRepository('AdminBundle:Opere' )->findAll();

        foreach($operes as $item){
            $data['id'] = $item->getId();
            $data['code'] = $item->getCode();

            $result[] = $data;

        }

        return $result;
    }


    public function allSubcategoryOpere(){

        $em = $this->get('doctrine')->getManager();
        $subcateg = $em->getRepository('AdminBundle:SubCategory' )->findAll();

        foreach($subcateg as $sub){

            $subcategory['id'] = $sub->getId();
            $subcategory['name'] = $sub->getDescription();
            $operes = $em->getRepository('AdminBundle:Opere')->findBy(array(
                'subcategory'=>$sub->getId()
            ));
           // echo count($operes);
            if(!empty($operes)){

                foreach($operes as $oper){
                    $temp['id'] = $oper->getId();
                    $temp['code'] = $oper->getCode();
                    $temp['identificazione'] = $oper->getIdentificazione();

                    $result_oper[] = $temp;
                }

                $result[] = array(
                    'subcategory'=>$subcategory,
                    'operes'=>$result_oper
                );

                unset($result_oper);
            }

        }
        //echo '<pre>';print_r($result);die;
        return $result;
      // $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!','result'=>$result);
        //return new Response(json_encode($response));

    }

    public function viewGaraAction(){

        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();
        $em = $this->get('doctrine')->getManager();
        $garas = $em->getRepository('AdminBundle:Gare' )->findAll();


        foreach($garas as $item){
            $data['id'] = $item->getId();
            $data['codigo'] = $item->getCodGara();
            $data['title'] = $item->getTitle();
            $data['importe'] = $item->getImporte();
            $data['capteam'] = $item->getCapTeam();
            $data['scadenzagrara'] = $item->getScadenzaGara()->format('d/m/y h:m:s');
            $data['scadenzacanditura'] = $item->getScadenzaCanditura()->format('d/m/y h:m:s');

            $result_gara[] = $data;
        }
        $result = $this->user_comp->getPersonalsInfo($id);
        $result['active_gare'] = 'active';
        $result['view_create'] = 'active';
        $projects = $this->user_comp->getAllProjects();


        return $this->render('AdminBundle:Admin:view_gara.html.twig', array(
            'datos'=>$result,
            'projects'=>$projects,
            'garas'=>(!empty($result_gara))?$result_gara:''
        ));

    }
    //delete gara
    public function deleteGaraAction($id){
        if(isset($id)){
            $em = $this->get('doctrine')->getManager();
            $gara = $em->getRepository('AdminBundle:Gare')->find($id);
            $em->remove($gara);
            $em->flush();

            $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!');
            return new Response(json_encode($response));

        }

    }

    public function getIdOperes($array){
        foreach($array as $item){
            $result[] = $item->getId();
        }

        return $result;
    }

    //calcular coincidencia x user
    public function calculateCoincidencia(){

        $em = $this->get('doctrine')->getManager();
        $resultoperes = $em->getRepository('AdminBundle:ResultOpere' )->findAll();		
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();

       foreach($resultoperes as $item){
          //$operes = $this->getIdOperes($item->getOperes());
			//echo '<pre>';print_r($item);die;
           $idformgara = $item->getFormgara()->getId();
		  // echo $idformgara;die;
           $formgara = $em->getRepository('AdminBundle:FormGara')->find($idformgara);
		   
		   

           $createBy =  $formgara->getCreateBy();


           //echo 'Username '.$createBy;die;

           $userformgara =  $em->getRepository('UsuarioBundle:User')->findOneBy(array(
                   'username'=>$createBy
               )
           );

           //echo '<pre>';print_r($userformgara);die;
           $data['id'] = $item->getId();
           $data['fullname'] = $formgara->getCreateBy();
           $data['namerol'] = $formgara->getGareteam()->getNameRol();
           $data['namegara'] = $item->getGare()->getTitle();
           $data['idformgara'] = $idformgara;

           $operesForm = $item->getFormgara()->getOperes();
           $cantoperes = count($operesForm);
           $idoperesFormGara = array();
           foreach($operesForm as $val){
               $idoperesFormGara[] = $val->getId();
           }

           //get operes gara
           $gara = $em->getRepository('AdminBundle:Gare')->find($item->getGare()->getId());
         // $user= $em->getRepository('UsuarioBundle:Gare')->find(array());
           $operes_gara = $gara->getOperes();

           $data['idgara'] = $gara->getId();

           $idoperesGara = array();

             foreach($operes_gara as $value){
                 $idoperesGara[] = $value->getId();
               }

                 $cont = 0;
               foreach($idoperesFormGara as $elem){
                   if(in_array($elem,$idoperesGara))
                       $cont++;
               }

           $percent = floatval(($cantoperes/count($idoperesGara))*100);
           $data['perecent'] = $percent;
           $data['iduser'] = $userformgara->getId();

           //crear Result Gara
           $resultGara = new ResultGara();

           //setear atributos
           $resultGara->setNameGara($item->getGare()->getTitle());
           $resultGara->setNameUser($formgara->getCreateBy());
           $resultGara->setNameFigure($formgara->getGareteam()->getNameRol());
           $resultGara->setPercent($percent);

           $em->persist($resultGara);
           $em->flush();

           $result[] = $data;
       }

        return $result;

        //echo '<pre>';print_r($result);die;

   }
   
   public function getAllUserCoincidencia(){
   }

    public function viewUserCoincidenciaAction(){

        $em = $this->get('doctrine')->getManager();
        $user = $this->get('security.context')->getToken()->getUser();
        $id = $user->getId();

        $result = $this->user_comp->getPersonalsInfo($id);
        $result['active_gare'] = 'active';
        $result['view_result'] = 'active';
        $projects = $this->user_comp->getAllProjects();


        return $this->render('AdminBundle:Admin:result_user_gara.html.twig', array(
            'datos'=>$result,
            'projects'=>$projects,
           'acertions'=>$this->calculateCoincidencia()
        ));

    }

    public function selectPersonGaraAction($id){

         //echo 'Hola '.$id;die;

        $em = $this->get('doctrine')->getManager();

        $user = $em->getRepository('UsuarioBundle:User')->find($id);
        $resultopere = $em->getRepository('AdminBundle:ResultGara')->findOneBy(array(
            'nameUser'=>$user->getUsername()
        ));



        //$figure = $em->getRepository('AdminBundle:Figure')->find($resultopere->getFigure()->getId());
        $name_figure = $resultopere->getNameFigure();

         $gara = $em->getRepository('AdminBundle:Gare')->find($_POST['id']);



        /*$result_opere = $em->getRepository('AdminBundle:ResultOpere')->findOneBy(array(
            'user'=>$id,
            'gares'=>$gara->getId(),
        ));*/

        $gareTeam = $em->getRepository('AdminBundle:GareTeam')->findOneBy(array('name_rol'=>$name_figure));

        //echo '<pre>';print_r($gareTeam);die;
      // echo 'Hola'.$result_opere->getGarateam()->getActive();die;

        if($gareTeam->getCantidad() == 0){
            $response = array("code" => 0, "success" => true,'mensaje'=>'This role has been assigned previously');
            return new Response(json_encode($response));
        }else{
             //actualizo value active gareTeam
            $cantidad = $gareTeam->getCantidad() - 1;
            $gareTeam->setCantidad($cantidad);
            $em->persist($gareTeam);
            $em->flush();

            //actualizo value cap_team de la tabla gare
           // $gare = $em->getRepository('AdminBundle:Gare')->find($resultopere->getGares()->getId());
            $cant = $gara->getCapTeam() - 1;
            $gara->setCapTeam($cant);
            $em->persist($gara);
            $em->flush();


            $userselectGara = new UserSelectGara();

            $userselectGara->setUser($user);
            $userselectGara->setGare($gara);

            $em->persist($userselectGara);
            $em->flush();

            //delete result
          /*  $em->remove($resultopere);
            $em->flush();*/

            //send email
            $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!');
            return new Response(json_encode($response));
        }

    }
    public function aceptGaraAction($id){
        $em = $this->get('doctrine')->getManager();
        $user = $this->get('security.context')->getToken()->getUser();
        $iduser = $user->getId();

            $gare = $em->getRepository('AdminBundle:Gare')->find($id);
            $userSelectGara = $em->getRepository('AdminBundle:UserSelectGara')->findOneBy(array('gare'=>$gare->getId()));

            $iduserGara = $userSelectGara->getUser()->getId();
            if($gare->getCapTeam()== 0){

                //buscar todos los gare  team
                $gareteams = $gare->getGareteams();

                foreach($gareteams as $item)
                {
                   $temp = $this->getDataUser($iduserGara);
                    if(!empty($temp)){
                        //echo $temp['id'];die;
                        $data['id'] =  $temp['id'];
                        $data['fullname'] =  $temp['fullname'];
                        $data['name_rol'] = $item->getNameRol();

                        $result[] = $data;
                    }

                }

            //echo '<pre>';print_r($result);die;
            $team = $em->getRepository('UsuarioBundle:Team')->findBy(
                array(),
                array('id' => 'ASC') ,
                1,
                0
            ) ;
            $code = $this->user_comp->generate_numbers(substr($team[count($team)-1]->getCode(),-1)+1,1,3)[0];
            $name = 'Team_'.$code;
            $createby = $iduser;
            $active = 1;
            //$user = $em->getRepository('UsuarioBundle:User' )->find($iduser);

            //create Team
            $team = new Team();
            $team->setName($name);
            $team->setCode($code);
            $team->setDescription("Team from Gara");
            $team->setCreateBy($createby);
            $team->setActivate($active);
            $team->setUser($user);

            foreach($result as $user){
                $profile = $em->getRepository('UsuarioBundle:Profile' )->findOneBy(array(
                    'user'=>$user['id']
                ));
                $team->addProfile($profile);
            }
            $em->persist($team);
            $em->flush();

            $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!');
            return new Response(json_encode($response));

            }
          else{
            $response = array("code" => 0, "success" => true,'mensaje'=>'Gara incompleta!!!');
            return new Response(json_encode($response));
        }

    }

    public function getDataUser($id){
        $em = $this->get('doctrine')->getManager();
        $user = $em->getRepository('UsuarioBundle:Profile')->findOneBy(array('user'=>$id));
        $data = array();
        if(isset($user)){
            $data['id'] = $id;
            $data['fullname'] = $user->getName().' '.$user->getLastname();
        };

       //echo '<pre>';print_r($data);die;

        return $data;

    }
    //Update gare
    public function updateGareAction($id){
        $em = $this->get('doctrine')->getManager();
        $user = $this->get('security.context')->getToken()->getUser();
        $iduser = $user->getId();
        $result = $this->user_comp->getPersonalsInfo($iduser);
        $result['active_gare'] = 'active';
        $result['view_result'] = 'active';
        $projects = $this->user_comp->getAllProjects();

        if(!empty($_POST)){

            //echo '<pre>';print_r($_POST);die;
            $gare = $em->getRepository('AdminBundle:Gare')->find($id);

            $scadenza_gara = $_POST['data']['scadenza_gare'];
            $scadenza_candi = $_POST['data']['scadenza_candi'];

            $tipologia = $em->getRepository('AdminBundle:TipologiaGara')->find($_POST['data']['tipologia']);


            // $gare->setCategory($category);
            $gare->setTitle($_POST['data']['title']);
            $gare->setRifBando($_POST['data']['rifbando']);
            $gare->setScadenzaGara(new \DateTime($scadenza_gara));
            $gare->setScadenzaCanditura(new \DateTime($scadenza_candi));
            $gare->setCodGara($_POST['data']['cod_gara']);
            $gare->setImporte($_POST['data']['importe']);
            $gare->setTipologia($tipologia);
            $gare->setObjective($_POST['data']['objetive']);
            $gare->setCapTeam($_POST['data']['tipologia']);


            foreach($_POST['data']['idopere'] as $val){
                $opere = $em->getRepository('AdminBundle:Opere')->findOneBy(array(
                    'code'=>$val
                ));

                $gare->addOpere($opere);
            }
            $id_gare = $gare->getId();
            //add gare Team

            foreach($_POST['data']['name_rol'] as $rol){
                $gareteam = new GareTeam();
                //$gareteam->setGare($gare);
                $gareteam->setNameRol($rol['name']);
                $gareteam->setCantidad($rol['cantidad']);
                //$gareteam->addGare($gare);

                $em->persist($gareteam);
                $em->flush();

                $gare->addGareteam($gareteam);
            }

            $em->persist($gare);
            $em->flush();

            $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!');
            return new Response(json_encode($response));

        }else{
            $gare = $em->getRepository('AdminBundle:Gare')->find($id);
            $tipologia = $em->getRepository('AdminBundle:TipologiaGara')->find($gare->getTipologia());

            $id_tipologia = $tipologia->getId();

            //echo '<pre>';$gare->getScadenzaGara()->getTimestamp();
           //echo '<pre>';$gare->getScadenzaGara()->format('Y-m-d h:i:s');

                $data['id'] = $gare->getId();
                $data['title'] = $gare->getTitle();
                $data['rifbando'] = $gare->getRifBando();
                $data['scadenzagara'] = $gare->getScadenzaGara()->format('Y-m-d h:m:s');
                $data['ecadenzacandi'] = $gare->getScadenzaCanditura()->format('Y-m-d h:m:s');
                $data['objetive'] = $gare->getObjective();
                $data['importe'] = $gare->getImporte();
                $data['codgara'] = $gare->getCodGara();
                $data['tipologia'] =  $id_tipologia;
                $data['cantteam'] = $gare->getCapTeam();


            foreach($gare->getOperes() as $opere){

                $temp['idopere'] = $opere->getId();
                $temp['code'] = $opere->getCode();
                $temp['identificazione'] = $opere->getIdentificazione();
               /* $temp['subcategory'] = array(
                    'idsubc'=>$opere->getSubcategory()->getid(),
                    'namecateg'=>$opere->getSubcategory()->getDescription()
                );*/

                $temp_result[] = $temp;
             }
            $data['operes'] = $temp_result;

            //get all Name Team
            $gare_teams = $gare->getGareteams();

            foreach($gare_teams as $item){
                $gareTeam[] = array(
                    'id'=>$item->getId(),
                    'name'=>$item->getNameRol(),
                    'cantidad'=>$item->getCantidad()
                );
            }

            $data['gareteam'] = $gareTeam;
            $jsonencoder = new JsonEncoder();
            $gareteam = $jsonencoder->encode($data['gareteam'],$format = 'json');


            $result['gara'] = $data;
            $categories = $this->getAllCategory();

            $operes = $gare->getOperes();

            foreach($operes as $value){
               //echo $value->getSubcategory()->getId();die;
                $oper['idsubcateg'] = is_object($value->getSubcategory())?$value->getSubcategory()->getId():null;
                $oper['name_subcateg'] = is_object($value->getSubcategory())?$value->getSubcategory()->getDescription():null;
                $oper['id'] = $value->getId();
                $oper['code'] = $value->getCode();

                $arr_operes [] = $oper;
            }

              //  echo '<pre>';print_r($arr_operes);die;

            //echo $this->notRepeatSubcategory($arr_operes);


            //$jsonencoder2 = new JsonEncoder();
            //$result_subcateg = $jsonencoder2->encode($subcategories,$format = 'json');

           // echo '<pre>';print_r($result);die;
            //echo '<pre>';print_r($result_subcateg); die;

            return $this->render('AdminBundle:Admin:update_gare.html.twig', array(
                'idgare'=>$id,
                'datos'=>$result,
                'projects'=>$projects,
                'gareteam'=>$gareteam,
                'subcategoperes'=>$this->allSubcategoryOpere(),
                'tipologias'=>$this->getTipologiasGara()
                //'jsonsubcateg'=>$result_subcateg
            ));

        }


    }
   /*S public function notRepeatSubcategory($arr = array()){

        $idsub = $arr[0]['idsubcateg'];
        $name_sucateg = $arr[0]['name_subcateg'];
        $arr_rsult[] = array();
       // $temp_opere = array();
        $temp_oper[0] = array('idoper'=>$arr[0]['id'],'code'=>$arr[0]['code']);
        $j = $k = 1;
        for($i = 1;$i<count($arr);$i++){
            if(isset($arr[$i]['idsubcateg'])){
                if($arr[$i] == $idsub){
                    $temp_oper[$j] = array('idoper'=>$arr[$i]['id'],'code'=>$arr[$i]['code']);
                    $j++;
                }else{
                    $arr_rsult[] = array(array('idsubcateg'=>$idsub,'name_sucateg'=>$name_sucateg,'opere'=>$temp_oper));
                    $idsub = $arr[$i]['idsubcateg'];
                    $name_sucateg = $arr[$i]['idsubcateg'];
                    $j = 0;
                }
                //unset($temp_oper);
            }

        }

        echo '<pre>';print_r($arr_rsult);die;

    }*/

    //all subcategory by id
    public function getAllSubCategoryId($id){

        $em = $this->get('doctrine')->getManager();
        $subcateg = $em->getRepository('AdminBundle:SubCategory' )->findBy(array(
            'category'=>$id
        ));

        foreach($subcateg as $sub){

            $subcategory['id'] = $sub->getId();
            $subcategory['name'] = $sub->getDescription();
            $operes = $em->getRepository('AdminBundle:Opere')->findBy(array(
                'subcategory'=>$sub->getId()
            ));
            // echo count($operes);
            if(!empty($operes)){

                foreach($operes as $oper){
                    $temp['id'] = $oper->getId();
                    $temp['code'] = $oper->getCode();
                    $temp['identificazione'] = $oper->getIdentificazione();

                    $result_oper[] = $temp;
                }

                $result[] = array(
                    'subcategory'=>$subcategory,
                    'operes'=>$result_oper
                );

                unset($result_oper);
            }

        }

        //echo '<pre>';print_r($result);die;
        return $result;

    }

    public function deleteResultGaraAction($id){

        if(isset($id)){
            $em = $this->get('doctrine')->getManager();
            $resultGare = $em->getRepository('AdminBundle:FormGara')->find($id);
			$resultOpere = $em->getRepository('AdminBundle:ResultOpere')->findOneBy(array('formgara'=>$id));
            $em->remove($resultOpere);
            $em->remove($resultGare);
            $em->flush();
          

            $response = array("code" => 1, "success" => true,'mensaje'=>'OKKK!!!');
            return new Response(json_encode($response));

        }

    }

    public  function getTipologiasGara(){
        $em = $this->get('doctrine')->getManager();
        $tipologias = $em->getRepository('AdminBundle:TipologiaGara')->findAll();

        foreach($tipologias as $tipo){
            $data['id'] = $tipo->getId();
            $data['name'] = $tipo->getName();

            $result[] = $data;

        }
        return $result;
    }

} 