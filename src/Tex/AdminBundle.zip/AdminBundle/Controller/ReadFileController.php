<?php

namespace Tex\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Tex\AdminBundle\Entity\Member;
use Tex\UsuarioBundle\Entity\User;
use Tex\UsuarioBundle\Entity\Formation;
use Tex\UsuarioBundle\Entity\Project;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Serializer\Encoder\JsonEncoder;

class ReadFileController extends Controller
{
    public function loadFileAction(){

        $em = $this->get('doctrine')->getManager();
        $u = $this->get('security.context')->getToken()->getUser();
        $id = $u->getId();
        //contar numero de user
        // $projects = $em->getRepository('ProyectoBundle:Project' )->findAll();
        $result = $this->getPersonalsInfo();
        $result["project_active"] = "";
        $result["formation_active"] = "";
        $result["projects_active"] = "";
        $result["create_active"] = "";
        $result["create_offer_job"] = "";
        $result["view_offer_job"] = "";
        $result["offer_job"] = "";
        $result["list_active"] = "";
        $result["display"] = "";
        $projects = $this->getAllProjects();
        //$messages =  $this->getMsgUser();
        //echo '<pre>';print_r($user);die;

         $jsonencoder = new JsonEncoder();
        $jsonCoordenadas = $jsonencoder->encode($result['coordenadas'],$format = 'json');

        //echo '<pre>';print_r($jsonCoordenadas);
        return $this->render('AdminBundle:Admin:load_file.html.twig', array(
            'datos'=>$result,
            'projects'=>$projects,
            'coordenadas'=>$jsonCoordenadas
            //'messages'=>$messages
        ));

    }
	    //get all coordenadas
    function getAllCoordenate(){

        $em = $this->get('doctrine')->getManager();
        $users = $em->getRepository('UsuarioBundle:User')->findAll();

        foreach($users as $user){
            $array[] = array('lat'=>$user->getLatitud(),'lng'=>$user->getLongitud());
        }

        return $array;
    }


    private function getPersonalsInfo($iduser = 0){
        if ($iduser)
            $id = $iduser;
        else{
            $user = $this->get('security.context')->getToken()->getUser();
            $id = $user->getId();
        }
        $em = $this->get('doctrine')->getManager();
        $user = $em->getRepository('UsuarioBundle:User')->find($id);
        $result['email'] = $user->getEmail();

        $profile = $em->getRepository('UsuarioBundle:Profile')->findOneBy(array('user'=>$id));
        $result['name'] = $profile->getName();
        $result['lastname'] = $profile->getLastname();
        $result['fullname'] = $profile->getName().' '.$profile->getLastname();
        $result['country'] =  $profile->getCountry();
        $result["avatar"] = $profile->getAvatar();
        $result['phone'] = $profile->getPhone();
        $result['mobile'] = $profile->getMobile();
        $result['address'] = $profile->getAddrees();
        $result['birthday'] = $profile->getBirthday();
		$result['coordenadas'] = $this->getAllCoordenate();
        $result["profile_active"] = "";
        $result["projects_active"] = "";
        $result["create_pro_activite"] = "";
        $result["create_emplo_activite"] = "";
        $result["employee_active"] = "";
        $result["list_emplo_activite"] = "";
        $result["team_active"] = "";
        $result["create_team_active"] = "";
        $result["list_active"] = "";
        $result["create_offer_job"] = "";
        $result["offer_job"] = "";
        $result["display"] = "";
        return $result;
    }

    public function getAllProjects(){
        $em = $this->get('doctrine')->getManager();
        $projects = $em->getRepository('ProyectoBundle:Project' )->findAll();

        $result = array();
        foreach($projects as $obj){
            $result[] = array(
                'id_project'=>$obj->getId(),
                'name'=>$obj->getName());
        }

        return $result;
    }

    function uploadFile($file = array()){

        $allowedExtensions = array('csv');

        $flag = $this->searchExt($allowedExtensions,$this->extension($file['file']['name']));
        if($flag){

            //$dir = $_SERVER["DOCUMENT_ROOT"].'/GestionTex/web/upload/files/';
            $dir = $_SERVER["DOCUMENT_ROOT"].'/web/upload/files/';
            // echo $dir;die;
            /* if(!is_dir($dir)){
                 echo 1;
             }*/
            //  mkdir($dir,0777);
            // echo 'Directory';die;
            if(move_uploaded_file($file['file']['tmp_name'],$dir.'/'.$file['file']['name'])){
                // echo 111;
                sleep(3);
            }

        }

        $file = $dir.''.$file['file']['name'];

        return $file;

    }
    function searchExt($array,$filename){
        $esta = false;
        for($i = 0;$i<count($array) && !$esta;$i++){
            if($array[$i]== $filename){
                $esta = true;
            }
        }
        return $esta;
    }

    function extension($filename){

        return substr(strrchr($filename, '.'), 1);
    }

    public function uploadFileDataAction(){

         // echo '<pre>';print_r($_FILES);die;
        if(!empty($_FILES)){
           $dir =  $this->uploadFile($_FILES);
            $em = $this->get('doctrine')->getManager();

           // echo $dir;die;
            $csvFile = file("".$dir."");
            $data = [];
            foreach ($csvFile as $line) {
                $data[] = str_getcsv($line);
            }

            //echo '<pre>';print_r($data);die;

            for($i =1;$i<count($data);$i++){
                $member = new Member();

                
                $obj = $em->getRepository('AdminBundle:Member')->findOneBy(array(
                    'name'=>$data[$i][0]
                ));

                if(!isset($obj)){

                    $member->setName($data[$i][0]);
                    $member->setEmail($data[$i][2]);
                    $member->setCountry($data[$i][5]);
                    $member->setProfession($data[$i][13]);

                    $em->persist($member);
                    $em->flush();
                }

            }
            //echo count($data)-1;die;

            $response = array("code" => 1);
            return new Response(json_encode($response));
        }

    }

}
