<?php

namespace Tex\ProyectoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProyectoBundle extends Bundle
{
}
